export type ClassNameProps = {
  className?: string;
};

export type DataTestIdProps = {
  "data-testid"?: string;
};
