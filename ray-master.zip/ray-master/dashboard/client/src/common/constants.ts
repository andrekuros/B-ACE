export const API_REFRESH_INTERVAL_MS = 4000;
// Per job page refresh interval.
export const PER_JOB_PAGE_REFRESH_INTERVAL_MS = 10000;
