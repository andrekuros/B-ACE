export * from "./DurationText";
