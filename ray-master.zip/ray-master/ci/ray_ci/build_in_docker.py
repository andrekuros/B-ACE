from ci.ray_ci.builder import main

if __name__ == "__main__":
    main()
