from ci.ray_ci.tester import main

if __name__ == "__main__":
    main()
