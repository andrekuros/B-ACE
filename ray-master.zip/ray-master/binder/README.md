# Dependencies for mybinder.org

To run notebook examples directly in the browser with binder, we need to set up the right dependencies,
so that the launched notebook can import them right away.

The `requirements.txt` file contains dependencies for (most) of the notebooks in our documentation.
